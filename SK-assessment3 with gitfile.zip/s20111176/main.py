from car_park_management import car_park_management

# TODO bug found - if auto button press fast. it lock to on always 

if __name__ == '__main__':
    my_car_park = car_park_management("s20111176/app_config.yaml")